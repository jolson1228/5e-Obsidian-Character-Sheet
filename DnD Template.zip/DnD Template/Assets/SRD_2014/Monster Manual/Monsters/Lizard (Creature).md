### Lizard

*Tiny beast, unaligned*

**Armor Class** 10

**Hit Points** 2 (1d4)

**Speed** 20 ft., climb 20 ft.

| STR    | DEX     | CON     | INT    | WIS    | CHA    |
|--------|---------|---------|--------|--------|--------|
| 2 (-4) | 11 (+0) | 10 (+0) | 1 (-5) | 8 (-1) | 3 (-4) |

**Senses** darkvision 30 ft., passive Perception 9

**Languages** -

**Challenge** 0 (10 XP)

###### Actions

***Bite***. *Melee Weapon Attack:* +0 to hit, reach 5 ft., one target. *Hit:* 1 piercing damage.