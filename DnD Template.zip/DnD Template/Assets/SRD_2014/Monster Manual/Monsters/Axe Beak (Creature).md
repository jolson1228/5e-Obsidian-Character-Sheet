### Axe Beak

*Large beast, unaligned*

**Armor Class** 11

**Hit Points** 19 (3d10+3)

**Speed** 50 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 14 (+2) | 12 (+1) | 12 (+1) | 2 (-4) | 10 (+0) | 5 (-3) |

**Senses** passive Perception 10

**Languages** -

**Challenge** 1/4 (50 XP)

###### Actions

***Beak***. *Melee Weapon Attack:* +4 to hit, reach 5 ft., one target. *Hit:* 6 (1d8+2) slashing damage.

An **axe beak** is a tall flightless bird with strong legs and a heavy, wedge-shaped beak. It has a nasty disposition and tends to attack any unfamiliar creature that wanders too close.