### Weasel

*Tiny beast, unaligned*

**Armor Class** 13

**Hit Points** 1 (1d4-1)

**Speed** 30 ft.

| STR    | DEX     | CON    | INT    | WIS     | CHA    |
|--------|---------|--------|--------|---------|--------|
| 3 (-4) | 16 (+3) | 8 (-1) | 2 (-4) | 12 (+1) | 3 (-4) |

**Skills** Perception +3, Stealth +5

**Senses** passive Perception 13

**Languages** -

**Challenge** 0 (10 XP)

***Keen Hearing and Smell***. The weasel has advantage on Wisdom (Perception) checks that rely on hearing or smell.

###### Actions

***Bite***. *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 1 piercing damage.