### Pony

*Medium beast, unaligned*

**Armor Class** 10

**Hit Points** 11 (2d8+2)

**Speed** 40 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 15 (+2) | 10 (+0) | 13 (+1) | 2 (-4) | 11 (+0) | 7 (-2) |

**Senses** passive Perception 10

**Languages** -

**Challenge** 1/8 (25 XP)

###### Actions

***Hooves***. *Melee Weapon Attack:* +4 to hit, reach 5 ft., one target. *Hit:* 7 (2d4+2) bludgeoning damage.