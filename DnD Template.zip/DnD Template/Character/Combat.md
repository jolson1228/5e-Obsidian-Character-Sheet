| Action   |  Range   | Hit/DC  | Damage |
|:-------- |:------:|:-----:|:--------- |
| Battleaxe  | 5 ft. | +8  | `1d8+5`/`1d10+5` Slashing |
| Glaive | 10 ft.&nbsp; | +8  | `1d10+5` Slashing  |
| Greataxe  |    5 ft.     |   +8    | `1d12+5` Slashing    |
| *Eldritch Blast*  |   120 ft.    |   +8    | `1d10+5` Force   |
| [Grapple](Grapple.md) |    5 ft.   | STR 15  | -    |
| [Shove](Shove.md) |    5 ft.     | STR 15. | -        | 

# 
	


# 

| Cantrip               |    Range     | Hit/DC | Effect   |
|:--------------------- |:------------:|:------:|:-------- |
| Eldritch Blast *(x2)* |   120 ft.    |   +8   | `1d10+5` |
| Mage Hand             |    30 ft.    |   -    | Utility  |
| Mind Sliver           |    60 ft.    | INT 16 | `2d6`    |
| Sword Burst           | Self / 5 ft. | DEX 16 | `2d6`    |

# 

| Spell             | Time |     Range     | Hit/DC | Effect  |
|:----------------- |:----:|:-------------:|:------:|:------- |
| Arms of Hadar     |  1A  | Self / 10 ft. | STR 16 | `4d6`   |
| Counterspell      |  1R  | 60 ft.&nbsp;  |   -    | Utility |
| Hex               | 1BA  |    90 ft.     |   -    | +`1d6`  |
| Rings of the Wise |  1A  |     Self      |   -    | `1d8`   |
| Shatter           |  1A  |    60 ft.     | CON 16 | `4d8`   |
| Shield of Fury    |  1R  |    10 ft.     |   -    | Utility |





# 

